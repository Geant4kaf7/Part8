#ifndef SD_Si_det_HH
#define SD_Si_det_HH

#include <G4Material.hh>
#include "G4NistManager.hh"
#include <G4VSensitiveDetector.hh>
#include <G4Step.hh>
#include <G4HCofThisEvent.hh>
#include <G4AutoLock.hh>
#include <fstream>
#include <iostream>
#include <sstream>
#include <stdio.h>
#include <string.h>

#include "SD_Si_det_hit.hh"

class SD_Si_det : public G4VSensitiveDetector
{
 G4Mutex aMutex=G4MUTEX_INITIALIZER;
 public:
  SD_Si_det(G4String SDname, G4String filename[10]);
  ~SD_Si_det();
//  G4AutoLock(&aMutex);

  void Initialize(G4HCofThisEvent* HCE);
  G4bool ProcessHits(G4Step* astep, G4TouchableHistory* ROhist); 
  void EndOfEvent(G4HCofThisEvent* HCE);

  G4double GetSumE(G4int i) const {return SumE[i];}
  void AddSumE(double e, G4int i) {SumE[i]+=e;}
  G4double GetCopyNum(G4int i) const {return CopyNum[i];}
  void SetCopyNum(G4int i) {CopyNum[i]=i+1;}
 private:
  std::ofstream hit_SD_Si_det[10];
  G4double SumE[10];
  G4int CopyNum[10];
  
  SD_Si_det_hitCollection *hitCollection;
  G4int collectionID;    
};

#endif

