#ifndef FINAL_PRIMARYPART_HH
#define FINAL_PRIMARYPART_HH

#include <G4VUserPrimaryGeneratorAction.hh>
#include <G4ParticleGun.hh>
#include <G4Gamma.hh>
#include <G4Proton.hh>
#include <G4Neutron.hh>
#include <G4SystemOfUnits.hh>
#include <G4AutoLock.hh>

#include "Randomize.hh"

#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>

class PrimaryPart: public G4VUserPrimaryGeneratorAction{
private:
 G4ParticleGun* GProton;
 G4ParticleGun* GNeutron;

 G4double E0;
 void SetE0(G4double En){E0=En;}
 G4double GetE0() const {return E0;}

public:
 PrimaryPart(std::ofstream&);
~PrimaryPart();

 std::ofstream *f_prim;

 virtual void GeneratePrimaries(G4Event* anEvent);
 
 G4ParticleGun* GetParticleGun() {return GProton;} 

};

#endif //FINAL_PRIMARYPART_HH
