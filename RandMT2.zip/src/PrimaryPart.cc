#include <PrimaryPart.hh>

#include <G4AutoLock.hh>
namespace {G4Mutex PrimPartMutex = G4MUTEX_INITIALIZER;}

PrimaryPart::PrimaryPart(std::ofstream& ofsa)
{
 G4AutoLock lock(PrimPartMutex);
 char string[1000];
 std::ifstream init;
 G4double E0;
 init.open("./in/input.dat");
 init.getline(string,1000);
 init>>E0; this->SetE0(E0);
 init.close();
 GProton = new G4ParticleGun(1);
 GProton->SetParticleDefinition(G4Proton::ProtonDefinition());

 this->f_prim=&ofsa;
 int thr=G4Threading::G4GetThreadId();
 (*f_prim) << std::setw(12) << "Hi from PrimaryPart! " <<this->GetE0()<< " local thread=" << thr << std::endl;
}

PrimaryPart::~PrimaryPart() 
{
 G4AutoLock lock(PrimPartMutex);
 int thr=G4Threading::G4GetThreadId();
 (*f_prim) << std::setw(12) << "Bye from PrimaryPart! " << " local thread=" << thr << std::endl;
}

//��������� ���������
void PrimaryPart::GeneratePrimaries(G4Event* anEvent) 
{
 G4AutoLock lock(PrimPartMutex);
 std::string fileName="./random/runevt.rndm";
 std::string fileName1="./random/myfile.rndm";
// CLHEP::HepRandom::getTheEngine()->restoreStatus(fileName.c_str());
 CLHEP::HepRandom::getTheEngine()->saveStatus(fileName1.c_str());
 GProton->SetParticleEnergy(this->GetE0() * MeV);
 GProton->SetParticleMomentumDirection(G4ThreeVector(0, 0, 1));
 G4double x_position=(G4UniformRand()-0.5)*20.*cm;
 G4double y_position=(G4UniformRand()-0.5)*2.*cm; 
 GProton->SetParticlePosition(G4ThreeVector(x_position, y_position, -5.*cm));
 GProton->GeneratePrimaryVertex(anEvent);
}

