#ifndef CPROJECT_DETGEOMETRY_HH
#define CPROJECT_DETGEOMETRY_HH

#include "Si_det_Parameterisation.hh"
#include "SD_Si_det.hh"
#include <G4UserLimits.hh>
#include <G4SDManager.hh>
#include <G4SystemOfUnits.hh>
#include <G4SolidStore.hh>
#include <G4LogicalVolumeStore.hh>
#include <G4PhysicalVolumeStore.hh>
#include <G4NistManager.hh>
#include <G4PVPlacement.hh>
#include <G4PVParameterised.hh>
#include <G4Box.hh>
#include <G4Tubs.hh>
#include <G4RunManager.hh>
#include <G4GeometryManager.hh>
#include <G4UImanager.hh>
#include <G4VUserDetectorConstruction.hh>
#include <G4VisAttributes.hh>
#include <G4Cache.hh>

#define SU *mm

class G4VPhysicalVolume;
class G4LogicalVolume;

//class GeomMes;

class Geometry  : public G4VUserDetectorConstruction
{
public:
    virtual G4VPhysicalVolume* Construct();
    void ConstructSDandField();
    G4NistManager*              nist;
    G4Material*                 world_mat;
    G4double                    world_size;
    G4Box*                      world_box;
    G4LogicalVolume*            world_log;    
    G4VPhysicalVolume*          world_pvpl;
	
    G4Box*			Pb_box;
    G4LogicalVolume*            Pb_log;
    G4VPhysicalVolume*          Pb_pvpl;
    G4ThreeVector		Pb_vect;
    
    G4Box*			Si_box;
    G4LogicalVolume*            Si_log;
    G4VPhysicalVolume*          Si_pvpl;
    G4ThreeVector		Si_vect;
    
    G4Box*			Si_det_box;
    G4LogicalVolume*            Si_det_log;
    G4VPhysicalVolume*          Si_det_pvpl;            

    G4Material* Pb_mat;
    G4Material* Si_mat;

    G4UserLimits* fStepLimit;

    std::ofstream *f_geom;
    Geometry(std::ofstream&);
    virtual ~Geometry();

private:
    G4String filename[10];

};

#endif //CPROJECT_DETGEOMETRY_HH
